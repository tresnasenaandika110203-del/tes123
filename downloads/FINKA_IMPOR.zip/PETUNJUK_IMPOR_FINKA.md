# Impor data Excel ke FinkaCare

Berkas `RESET_DAN_IMPOR_FINKA.sql` siap ditempel seluruhnya ke Supabase SQL Editor. Berkas ini disusun untuk skema PostgreSQL yang Anda berikan, dan belum dijalankan pada database aplikasi Anda.

## Menjalankan

1. Buat backup database yang sekarang. Penggantian data ini memang menghapus data bisnis lama.
2. Buka proyek Supabase yang dipakai FinkaCare, pilih **SQL Editor → New query**, gunakan role **postgres** / project owner.
3. Buka `RESET_DAN_IMPOR_FINKA.sql` di editor teks, salin **seluruh isinya**, tempel ke SQL Editor, lalu klik **Run** satu kali. Jangan hanya menjalankan bagian yang dipilih.
4. Cocokkan hasil jumlah tabel di bawah, lalu muat ulang aplikasi. Tinjau lembar **Temuan** dan **Obat** dalam `LAPORAN_IMPOR_FINKA.xlsx` sebelum mulai bertransaksi.

Jika ada error, jangan menjalankan potongan sisanya. Jalankan `ROLLBACK;` bila sesi masih menyatakan transaction aborted, lalu periksa pesan error. Seluruh penghapusan dan impor berada dalam satu transaksi. Tabel lain dengan foreign key ke data ini akan menyebabkan reset gagal; skrip sengaja tidak memakai CASCADE.

## Hasil yang diharapkan

| Tabel | Baris |
|---|---:|
| obat | 621 |
| batch_obat | 986 |
| supplier | 5 |
| penerimaan | 71 |
| detail_penerimaan | 472 |
| penjualan | 926 |
| detail_penjualan | 926 |
| mutasi_stok | 1944 |

Excel sumber memuat **987 baris master**, **472 baris penerimaan**, dan **926 baris pengeluaran**. Baris master mencakup beberapa batch untuk obat yang sama; karena itu jumlah obat aplikasi berbeda dari jumlah baris Excel. Ada **612 kombinasi nama/bentuk sediaan**, ditambah **9 varian satuan** yang hubungannya tidak dapat dipastikan, sehingga terbentuk **621 obat**. Total penjualan berdasarkan kolom `Total Pembelian` adalah **Rp23.060.500**.

## Data yang diganti dan dipertahankan

Data pada sembilan tabel berikut dikosongkan dan diganti: `obat`, `batch_obat`, `supplier`, `penerimaan`, `detail_penerimaan`, `mutasi_stok`, `pengaturan_opsi`, `penjualan`, dan `detail_penjualan`. Opsi kategori, bentuk sediaan, dan satuan diisi kembali dari hasil impor.

`auth.users` dan `public.admin_users` dipertahankan. Struktur tabel aplikasi, RLS, policy akses, dan fungsi aplikasi tidak diubah. Trigger pengguna pada sembilan tabel tersebut dinonaktifkan sementara di dalam transaksi untuk mencegah penghitungan ganda; status enabled/disabled/replica/always masing-masing dipulihkan sebelum commit. Foreign key dan CHECK constraint tetap aktif. Identity sequence disesuaikan setelah pengisian ID.

## Aturan pemetaan

- Nama obat digabung berdasarkan nama dan bentuk sediaan setelah spasi/case dibersihkan. Bentuk sediaan berbeda tetap menjadi produk berbeda. Kode `FKX-0001` dan seterusnya dibuat karena Excel tidak mempunyai kolom kode obat aplikasi.
- Kategori dibaca dari warna sel dan legenda `Keterangan Kategori Obat`. Tiga sel mempunyai warna di luar legenda; kategorinya dibiarkan NULL dan dicatat dalam laporan. Label `Scincare` dirapikan menjadi `Skincare`.
- Satuan dasar dipilih dari satuan yang benar-benar dipakai pada data. Isi kemasan dipakai untuk konversi jika hubungan satuannya diketahui. Untuk **Sutra 003 (Putih): 1 Dus = 10 Strip = 30 Pcs**, sesuai jawaban Anda. Stok akhir batch `M48251110` menjadi **31 Pcs**.
- Jika hubungan dua satuan tidak bisa dibuktikan, dibuat varian obat dengan satuan berbeda. Contoh: `Termorex Paracetamol Jeruk 60 ml` mempunyai catatan stok `Strip` tetapi kemasan/harganya `Pcs`. Angka-angkanya dipertahankan dan belum dianggap sebagai satuan yang sama.
- Harga jual mengikuti harga eksplisit satuan dasar. Jika tidak tersedia, harga diturunkan dari satuan kemasan yang faktor konversinya diketahui. Di antara pilihan sejenis, dipilih baris dengan tanggal masuk terbaru. `stok_minimum` diisi 0 karena tidak ada di Excel.
- **12 obat/varian tidak memiliki harga jual yang dapat dipastikan**. Nilai `harga_jual` tetap NULL dan `aktif=false` sebagai penanda untuk ditinjau, bukan diberi harga perkiraan. Pada kode kasir yang tersedia saat diperiksa, katalog kasir belum menyaring kolom `aktif`, dan harga NULL dapat tampil sebagai Rp0. **Lengkapi harga entri ini sebelum menggunakan kasir**; filter kolom `Aktif = FALSE` pada lembar `Obat` untuk melihat daftarnya.
- `PT,` dirapikan menjadi `PT.` pada nama supplier; variasi kapitalisasi `PT. NUROSADI` dan `PT. Nurosadi` digabung.
- Batch memakai kombinasi obat, nomor batch, dan tanggal kedaluwarsa. Saldo dari beberapa baris master dengan kombinasi yang sama dijumlahkan. Perbedaan nomor batch atau tanggal tidak diperbaiki secara tebakan.
- Ada 27 baris riwayat penerimaan dengan batch/bentuk/satuan/expired yang tidak cocok dengan master. Batch riwayat tersebut dipertahankan tersendiri dengan saldo akhir 0 karena tidak memiliki saldo STOCK AKHIR sendiri pada master. Lihat `batch_riwayat_tanpa_saldo_master` dalam laporan.
- Penerimaan digabung per nomor faktur + supplier + tanggal, menghasilkan 71 header dan 472 detail. Jumlah diutamakan dari kolom **Unit Kemasan (Satuan Dasar)**; dua baris yang kosong memakai kolom jumlah kemasan. Ada 15 baris yang jumlah dasar dan jumlah kemasannya tidak setara dengan informasi kemasan; jumlah dasar aslinya dipertahankan dan dicatat sebagai temuan.
- Setiap baris pengeluaran dijadikan satu penjualan dengan referensi `XLS-KELUAR-000006` dan seterusnya. Excel tidak menyediakan nomor struk atau pengelompokan pelanggan, sehingga baris pada hari yang sama tidak dianggap satu transaksi pelanggan. Tanggal memakai Asia/Jakarta, jam 00:00 karena waktu transaksi tidak tersedia.
- Subtotal dan total penjualan mengikuti `Total Pembelian` Excel. Harga satuan penjualan merupakan subtotal dibagi jumlah setelah konversi. Ini menjaga omzet tanpa menggandakan kolom `Pendapatan Perhari`.
- Skema tidak menyediakan kolom khusus isi kemasan, seluruh harga per satuan, harga beli, diskon, atau pajak. Nilai asli setiap baris penerimaan dan penjualan disimpan dalam `catatan` header sebagai JSON. Nilai master asli beserta kategori warna juga disertakan di staging SQL untuk audit selama eksekusi; setelah commit staging dihapus. **Simpan Excel sumber sebagai arsip permanen** untuk kolom master yang tidak punya tempat di skema aplikasi.

## Saldo dan rekonsiliasi

Saldo akhir aplikasi mengikuti **STOCK AKHIR** pada master, bukan stok awal ditambah lagi seluruh penerimaan. Seluruh 472 baris penerimaan dan 926 baris pengeluaran masuk ke riwayat mutasi, sedangkan saldo batch diisi langsung dari hasil konversi master.

Karena riwayat Excel tidak lengkap dan sebagian datanya tidak saling cocok, skrip menambah **546 mutasi rekonsiliasi** yang ditandai `XLS-SALDO-AWAL-...` atau `XLS-REKONSILIASI-...`. Saldo pembuka dipilih agar riwayat tidak menghasilkan saldo negatif; penyesuaian akhir menyamakan saldo dengan STOCK AKHIR. Ini bukan faktur pembelian atau transaksi penjualan, sehingga tidak menambah omzet. Tanggal pembuka ditempatkan sehari sebelum tanggal sumber pertama untuk batch; penyesuaian akhir pada pukul 23:59:59 tanggal sumber terakhir. Tanggal-tanggal ini hasil rekonstruksi, bukan tanggal transaksi tambahan yang ada di Excel.

Lembar **Rekonsiliasi** memperlihatkan saldo pembuka, net riwayat, penyesuaian keluar, dan saldo akhir untuk setiap batch. Skrip memeriksa bahwa saldo akhir mutasi sama dengan stok batch sebelum commit.

## Validasi

Diuji pada PostgreSQL lokal berbasis PGlite dengan tabel dan constraint sesuai skema yang Anda kirim:

- Impor penuh: lolos; jumlah baris, omzet, saldo batch, saldo berjalan, admin, RLS/policy, dan keempat status trigger diverifikasi.
- Impor dijalankan ulang: lolos; tidak menambah duplikasi.
- Kegagalan paksa sesudah TRUNCATE: lolos; seluruh data sebelumnya kembali.
- Foreign key dari tabel tambahan di luar daftar: lolos; reset dibatalkan, data tabel lain dipertahankan.

Pengujian tersebut tidak mengakses database Supabase Anda. Perbedaan constraint atau tabel tambahan di database sebenarnya dapat menyebabkan skrip dibatalkan; kirim pesan error tersebut jika terjadi.

SHA-256 Excel sumber: `c9b49e93c6f28826fa8c2c312cdd05665b13e9c1537dfb6ec42a7d4d0e51f027`.

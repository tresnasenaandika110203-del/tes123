-- FINKACARE: LANGKAH FINAL (26), PERBAIKAN UNIQUE BATCH + EXPIRED
-- FILE INI MENGISI DATA APLIKASI DARI STAGING YANG SUDAH LENGKAP.
-- Data lama sudah dihapus pada file 00. Jalankan setelah SEMUA file 01-25 berhasil.
-- Seluruh pengisian akhir berada dalam SATU transaksi. Jika gagal, pengisian ini dibatalkan.
-- Data yang telah dihapus pada file 00 tidak dapat dipulihkan dengan rollback file final; gunakan backup.
-- Aturan unik batch diubah menjadi (obat_id, nomor_batch, tanggal_kedaluwarsa), sesuai pilihan pengguna.
-- Nomor batch, semua tanggal kedaluwarsa dan stok sumber tetap dipertahankan.
-- Akun login/admin, RLS, policy dan fungsi aplikasi tetap dipertahankan.
-- Jangan jalankan ulang setelah berhasil dan aplikasi sudah dipakai bertransaksi.
BEGIN;
SET LOCAL lock_timeout = '10s';
SET LOCAL statement_timeout = '300s';
SET LOCAL standard_conforming_strings = on;
SET LOCAL TIME ZONE 'Asia/Jakarta';

LOCK TABLE finka_import_c9b49e93c6f2._meta, finka_import_c9b49e93c6f2._manifest, finka_import_c9b49e93c6f2._finka_obat, finka_import_c9b49e93c6f2._finka_batch, finka_import_c9b49e93c6f2._finka_supplier, finka_import_c9b49e93c6f2._finka_penerimaan, finka_import_c9b49e93c6f2._finka_detail_masuk, finka_import_c9b49e93c6f2._finka_penjualan, finka_import_c9b49e93c6f2._finka_detail_keluar, finka_import_c9b49e93c6f2._finka_mutasi, finka_import_c9b49e93c6f2._finka_master_asli IN EXCLUSIVE MODE;
DO $all_parts$
DECLARE r record; a record; actual_n bigint; t text; expected_n bigint;
BEGIN
 IF (SELECT package_id FROM finka_import_c9b49e93c6f2._meta WHERE singleton) IS DISTINCT FROM 'finka-c9b49e93c6f2-staged-v2' THEN
  RAISE EXCEPTION 'Paket staging tidak cocok. Gunakan semua file dari ZIP yang sama.';
 END IF;
 IF (SELECT phase FROM finka_import_c9b49e93c6f2._meta WHERE singleton) <> 'loading' THEN
  RAISE EXCEPTION 'Impor sudah berhasil diterapkan sebelumnya. File final tidak dijalankan ulang.';
 END IF;
 IF (SELECT count(*) FROM finka_import_c9b49e93c6f2._manifest)<>25 THEN RAISE EXCEPTION 'Jumlah bagian pada manifest tidak cocok.'; END IF;
 IF EXISTS(SELECT 1 FROM finka_import_c9b49e93c6f2._manifest WHERE loaded_at IS NULL) THEN
  RAISE EXCEPTION 'Data belum lengkap. File yang belum dimuat: %',
   (SELECT string_agg(filename,', ' ORDER BY part_no) FROM finka_import_c9b49e93c6f2._manifest WHERE loaded_at IS NULL);
 END IF;
 FOR r IN SELECT * FROM finka_import_c9b49e93c6f2._manifest ORDER BY part_no LOOP
  SELECT * INTO a FROM finka_import_c9b49e93c6f2._part_audit(r.part_no);
  IF a.row_count<>r.expected_rows OR a.row_count<>r.loaded_rows OR a.fingerprint IS DISTINCT FROM r.data_md5 THEN
   RAISE EXCEPTION 'Data staging bagian % tidak utuh/berubah; reset aplikasi dibatalkan.',r.part_no;
  END IF;
 END LOOP;
 FOR t,expected_n IN SELECT * FROM (VALUES
('_finka_obat',621::bigint),
('_finka_batch',986::bigint),
('_finka_supplier',5::bigint),
('_finka_penerimaan',71::bigint),
('_finka_detail_masuk',472::bigint),
('_finka_penjualan',926::bigint),
('_finka_detail_keluar',926::bigint),
('_finka_mutasi',1944::bigint),
('_finka_master_asli',987::bigint)) v(tbl,n) LOOP
  EXECUTE format('SELECT count(*) FROM %I.%I','finka_import_c9b49e93c6f2',t) INTO actual_n;
  IF actual_n<>expected_n THEN RAISE EXCEPTION 'Jumlah staging % tidak cocok: % <> %',t,actual_n,expected_n; END IF;
 END LOOP;
 IF (SELECT sum(total) FROM finka_import_c9b49e93c6f2._finka_penjualan) <> 23060500 THEN
  RAISE EXCEPTION 'Total penjualan sumber tidak cocok. Reset dibatalkan.';
 END IF;
END
$all_parts$;

-- Semua data sumber sudah tersedia di staging. Mulai penggantian data bisnis secara atomik.
-- Tanpa CASCADE: referensi dari tabel lain yang tidak diketahui akan membatalkan seluruh transaksi.
LOCK TABLE public.obat, public.batch_obat, public.supplier, public.penerimaan,
 public.detail_penerimaan, public.mutasi_stok, public.pengaturan_opsi,
 public.penjualan, public.detail_penjualan IN ACCESS EXCLUSIVE MODE;

-- Pertahankan seluruh tanggal kedaluwarsa dari Excel.
-- Ubah hanya aturan UNIQUE dua kolom (obat_id, nomor_batch) menjadi UNIQUE tiga kolom.
-- Tidak memakai CASCADE. Jika aturan lama dirujuk objek lain, seluruh file dibatalkan.
DO $batch_unique_by_expiry$
DECLARE
 r record;
 two_cols smallint[];
 three_cols smallint[];
BEGIN
 SELECT array_agg(attnum::smallint ORDER BY attnum) INTO two_cols
 FROM pg_attribute WHERE attrelid='public.batch_obat'::regclass
 AND attname IN ('obat_id','nomor_batch') AND attnum>0 AND NOT attisdropped;
 SELECT array_agg(attnum::smallint ORDER BY attnum) INTO three_cols
 FROM pg_attribute WHERE attrelid='public.batch_obat'::regclass
 AND attname IN ('obat_id','nomor_batch','tanggal_kedaluwarsa') AND attnum>0 AND NOT attisdropped;
 IF cardinality(two_cols)<>2 OR cardinality(three_cols)<>3 THEN
  RAISE EXCEPTION 'Kolom batch yang diperlukan tidak ditemukan; aturan unik tidak diubah.';
 END IF;
 -- Hanya constraint UNIQUE yang tepat pada dua kolom tersebut; primary key tetap.
 FOR r IN
  SELECT conname FROM pg_constraint c
  WHERE c.conrelid='public.batch_obat'::regclass AND c.contype='u'
  AND ARRAY(SELECT x FROM unnest(c.conkey) x ORDER BY x)=two_cols
 LOOP
  EXECUTE format('ALTER TABLE public.batch_obat DROP CONSTRAINT %I',r.conname);
 END LOOP;
 -- Tangani pula aturan yang dibuat sebagai indeks UNIQUE mandiri, bukan constraint.
 FOR r IN
  SELECT ns.nspname,idx.relname
  FROM pg_index i JOIN pg_class idx ON idx.oid=i.indexrelid
  JOIN pg_namespace ns ON ns.oid=idx.relnamespace
  WHERE i.indrelid='public.batch_obat'::regclass AND i.indisunique AND NOT i.indisprimary
   AND i.indpred IS NULL AND i.indexprs IS NULL AND i.indnkeyatts=2
   AND ARRAY(SELECT x.attnum FROM unnest(i.indkey) WITH ORDINALITY AS x(attnum,pos)
             WHERE x.pos<=i.indnkeyatts ORDER BY x.attnum)=two_cols
   AND NOT EXISTS(SELECT 1 FROM pg_constraint c WHERE c.conindid=i.indexrelid)
 LOOP
  EXECUTE format('DROP INDEX %I.%I',r.nspname,r.relname);
 END LOOP;
 -- Hindari membuat constraint tiga kolom kedua jika sudah ada aturan setara.
 IF NOT EXISTS(
  SELECT 1 FROM pg_constraint c WHERE c.conrelid='public.batch_obat'::regclass AND c.contype='u'
   AND ARRAY(SELECT x FROM unnest(c.conkey) x ORDER BY x)=three_cols
 ) THEN
  IF EXISTS(SELECT 1 FROM pg_constraint WHERE conrelid='public.batch_obat'::regclass
            AND conname='batch_obat_obat_nomor_exp_key') THEN
   RAISE EXCEPTION 'Nama constraint tiga kolom sudah dipakai aturan lain; tidak diubah otomatis.';
  END IF;
  ALTER TABLE public.batch_obat ADD CONSTRAINT batch_obat_obat_nomor_exp_key
   UNIQUE(obat_id,nomor_batch,tanggal_kedaluwarsa);
 END IF;
END
$batch_unique_by_expiry$;

-- Verifikasi isi staging SEBELUM penghapusan.
DO $preflight$
BEGIN
 IF (SELECT count(*) FROM finka_import_c9b49e93c6f2._finka_master_asli) <> 987
    OR (SELECT count(*) FROM finka_import_c9b49e93c6f2._finka_penjualan) <> 926 THEN
   RAISE EXCEPTION 'Jumlah baris sumber tidak sesuai; reset dibatalkan.';
 END IF;
 IF EXISTS (
  SELECT 1 FROM finka_import_c9b49e93c6f2._finka_batch b LEFT JOIN (
   SELECT batch_id, sum(CASE WHEN jenis='masuk' THEN jumlah ELSE -jumlah END) saldo
   FROM finka_import_c9b49e93c6f2._finka_mutasi GROUP BY batch_id
  ) m ON m.batch_id=b.id WHERE abs(b.stok-coalesce(m.saldo,0)) > 0.00000001
 ) THEN RAISE EXCEPTION 'Saldo mutasi staging tidak cocok dengan STOCK AKHIR.'; END IF;
 IF EXISTS (
  SELECT 1 FROM finka_import_c9b49e93c6f2._finka_penjualan p LEFT JOIN (
   SELECT penjualan_id,sum(subtotal) total FROM finka_import_c9b49e93c6f2._finka_detail_keluar GROUP BY penjualan_id
  ) d ON d.penjualan_id=p.id WHERE abs(p.total-coalesce(d.total,0)) > 0.00000001
 ) THEN RAISE EXCEPTION 'Total penjualan staging tidak cocok.'; END IF;
END
$preflight$;

-- Hindari trigger aplikasi menghitung stok/riwayat dua kali. Trigger internal FK tetap aktif.
-- Keadaan awal trigger (enabled/disabled/replica/always) dikembalikan tepat seperti semula.
CREATE TEMP TABLE _finka_trigger_awal ON COMMIT DROP AS
SELECT n.nspname AS schema_name,c.relname AS table_name,t.tgname AS trigger_name,t.tgenabled
FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace
WHERE n.nspname='public' AND c.relname IN ('obat','batch_obat','supplier','penerimaan',
 'detail_penerimaan','mutasi_stok','pengaturan_opsi','penjualan','detail_penjualan') AND NOT t.tgisinternal;
DO $pause_triggers$
DECLARE r record;
BEGIN
 FOR r IN SELECT DISTINCT schema_name,table_name FROM _finka_trigger_awal LOOP
  EXECUTE format('ALTER TABLE %I.%I DISABLE TRIGGER USER',r.schema_name,r.table_name);
 END LOOP;
END
$pause_triggers$;

-- Penghapusan dilakukan hanya oleh file 00. Pastikan tabel aplikasi masih kosong sebelum diisi.
DO $targets_empty$
DECLARE tbl text; actual_n bigint;
BEGIN
 FOREACH tbl IN ARRAY ARRAY['obat','batch_obat','supplier','penerimaan','detail_penerimaan','mutasi_stok','pengaturan_opsi','penjualan','detail_penjualan'] LOOP
  EXECUTE format('SELECT count(*) FROM public.%I',tbl) INTO actual_n;
  IF actual_n<>0 THEN RAISE EXCEPTION 'Tabel public.% berisi data baru. Hentikan penggunaan aplikasi selama impor. Final dibatalkan tanpa menghapus data baru tersebut.',tbl; END IF;
 END LOOP;
END
$targets_empty$;

INSERT INTO public.obat (id,kode_obat,nama_obat,bentuk_sediaan,satuan_dasar,stok_minimum,harga_jual,kategori,jenis_obat,aktif)
OVERRIDING SYSTEM VALUE
SELECT id,kode,nama,bentuk,satuan,0,harga,kategori,jenis,(harga IS NOT NULL) FROM finka_import_c9b49e93c6f2._finka_obat ORDER BY id;
INSERT INTO public.supplier (id,nama_supplier,aktif) OVERRIDING SYSTEM VALUE
SELECT id,nama,true FROM finka_import_c9b49e93c6f2._finka_supplier ORDER BY id;
INSERT INTO public.batch_obat (id,obat_id,nomor_batch,tanggal_kedaluwarsa,stok_tersedia) OVERRIDING SYSTEM VALUE
SELECT id,obat_id,nomor,expired,stok FROM finka_import_c9b49e93c6f2._finka_batch ORDER BY id;
INSERT INTO public.penerimaan (id,nomor_faktur,supplier_id,tanggal_penerimaan,catatan,created_at) OVERRIDING SYSTEM VALUE
SELECT id,faktur,supplier_id,tanggal,catatan,tanggal::timestamp AT TIME ZONE 'Asia/Jakarta' FROM finka_import_c9b49e93c6f2._finka_penerimaan ORDER BY id;
INSERT INTO public.detail_penerimaan (penerimaan_id,batch_id,jumlah)
SELECT penerimaan_id,batch_id,jumlah FROM finka_import_c9b49e93c6f2._finka_detail_masuk;
INSERT INTO public.penjualan (id,referensi,tanggal_transaksi,total,catatan,created_at) OVERRIDING SYSTEM VALUE
SELECT id,referensi,tanggal,total,catatan,tanggal FROM finka_import_c9b49e93c6f2._finka_penjualan ORDER BY id;
INSERT INTO public.detail_penjualan (penjualan_id,batch_id,jumlah,harga_satuan,subtotal)
SELECT penjualan_id,batch_id,jumlah,harga,subtotal FROM finka_import_c9b49e93c6f2._finka_detail_keluar;
INSERT INTO public.mutasi_stok (batch_id,jenis_mutasi,jumlah,referensi,catatan,created_at)
SELECT batch_id,jenis,jumlah,referensi,catatan,tanggal FROM finka_import_c9b49e93c6f2._finka_mutasi ORDER BY tanggal,CASE WHEN jenis='masuk' THEN 0 ELSE 1 END,batch_id;
INSERT INTO public.pengaturan_opsi (jenis,nilai)
SELECT 'kategori',kategori FROM finka_import_c9b49e93c6f2._finka_obat WHERE kategori IS NOT NULL
UNION SELECT 'bentuk_sediaan',bentuk FROM finka_import_c9b49e93c6f2._finka_obat WHERE bentuk IS NOT NULL
UNION SELECT 'satuan_dasar',satuan FROM finka_import_c9b49e93c6f2._finka_obat;

-- OVERRIDING SYSTEM VALUE tidak memajukan sequence otomatis. Sinkronkan semua identity.
DO $sequences$
DECLARE tbl text; seq_name text; max_id bigint;
BEGIN
 FOREACH tbl IN ARRAY ARRAY['obat','batch_obat','supplier','penerimaan','detail_penerimaan','penjualan','detail_penjualan','mutasi_stok'] LOOP
  SELECT pg_get_serial_sequence(format('public.%I',tbl),'id') INTO seq_name;
  IF seq_name IS NULL THEN RAISE EXCEPTION 'Identity sequence %.id tidak ditemukan.',tbl; END IF;
  EXECUTE format('SELECT max(id) FROM public.%I',tbl) INTO max_id;
  PERFORM setval(seq_name::regclass,coalesce(max_id,1),max_id IS NOT NULL);
 END LOOP;
END
$sequences$;

DO $restore_triggers$
DECLARE r record; action text;
BEGIN
 FOR r IN SELECT * FROM _finka_trigger_awal LOOP
  action := CASE r.tgenabled WHEN 'O' THEN 'ENABLE TRIGGER' WHEN 'D' THEN 'DISABLE TRIGGER'
   WHEN 'R' THEN 'ENABLE REPLICA TRIGGER' WHEN 'A' THEN 'ENABLE ALWAYS TRIGGER' END;
  IF action IS NULL THEN RAISE EXCEPTION 'Status trigger tidak dikenal.'; END IF;
  EXECUTE format('ALTER TABLE %I.%I %s %I',r.schema_name,r.table_name,action,r.trigger_name);
 END LOOP;
END
$restore_triggers$;

-- Verifikasi hasil akhir. Kegagalan membatalkan perubahan constraint dan pengisian file 26; staging tetap tersedia.
DO $verify$
DECLARE tbl text; actual_n bigint; expected_n bigint;
BEGIN
 FOR tbl,expected_n IN
  SELECT 'obat',count(*) FROM finka_import_c9b49e93c6f2._finka_obat UNION ALL SELECT 'batch_obat',count(*) FROM finka_import_c9b49e93c6f2._finka_batch
  UNION ALL SELECT 'supplier',count(*) FROM finka_import_c9b49e93c6f2._finka_supplier UNION ALL SELECT 'penerimaan',count(*) FROM finka_import_c9b49e93c6f2._finka_penerimaan
  UNION ALL SELECT 'detail_penerimaan',count(*) FROM finka_import_c9b49e93c6f2._finka_detail_masuk UNION ALL SELECT 'penjualan',count(*) FROM finka_import_c9b49e93c6f2._finka_penjualan
  UNION ALL SELECT 'detail_penjualan',count(*) FROM finka_import_c9b49e93c6f2._finka_detail_keluar UNION ALL SELECT 'mutasi_stok',count(*) FROM finka_import_c9b49e93c6f2._finka_mutasi
 LOOP
  EXECUTE format('SELECT count(*) FROM public.%I',tbl) INTO actual_n;
  IF actual_n<>expected_n THEN RAISE EXCEPTION 'Verifikasi jumlah % gagal: % <> %',tbl,actual_n,expected_n; END IF;
 END LOOP;
 IF EXISTS (SELECT 1 FROM public.batch_obat b JOIN finka_import_c9b49e93c6f2._finka_batch s ON s.id=b.id WHERE abs(b.stok_tersedia-s.stok)>0.00000001)
 THEN RAISE EXCEPTION 'Saldo batch hasil impor berbeda dari Excel.'; END IF;
 IF EXISTS (
  SELECT 1 FROM public.batch_obat b LEFT JOIN (
   SELECT batch_id,sum(CASE WHEN jenis_mutasi='masuk' THEN jumlah ELSE -jumlah END) saldo
   FROM public.mutasi_stok GROUP BY batch_id
  ) m ON m.batch_id=b.id WHERE abs(b.stok_tersedia-coalesce(m.saldo,0))>0.00000001
 ) THEN RAISE EXCEPTION 'Saldo akhir mutasi tidak sama dengan saldo batch.'; END IF;
 IF EXISTS (
  SELECT 1 FROM public.penjualan p LEFT JOIN (
   SELECT penjualan_id,sum(subtotal) total FROM public.detail_penjualan GROUP BY penjualan_id
  ) d ON d.penjualan_id=p.id WHERE abs(p.total-coalesce(d.total,0))>0.00000001
 ) THEN RAISE EXCEPTION 'Total hasil impor tidak cocok dengan detail penjualan.'; END IF;
 IF EXISTS (
  SELECT 1 FROM _finka_trigger_awal a JOIN pg_namespace n ON n.nspname=a.schema_name
  JOIN pg_class c ON c.relnamespace=n.oid AND c.relname=a.table_name
  JOIN pg_trigger t ON t.tgrelid=c.oid AND t.tgname=a.trigger_name WHERE t.tgenabled<>a.tgenabled
 ) THEN RAISE EXCEPTION 'Status trigger tidak berhasil dikembalikan.'; END IF;
END
$verify$;

-- Hasil ringkas muncul di panel Results SQL Editor jika impor berhasil.
SELECT 'obat' AS tabel,count(*) AS jumlah FROM public.obat
UNION ALL SELECT 'batch_obat',count(*) FROM public.batch_obat
UNION ALL SELECT 'supplier',count(*) FROM public.supplier
UNION ALL SELECT 'penerimaan',count(*) FROM public.penerimaan
UNION ALL SELECT 'detail_penerimaan',count(*) FROM public.detail_penerimaan
UNION ALL SELECT 'penjualan',count(*) FROM public.penjualan
UNION ALL SELECT 'detail_penjualan',count(*) FROM public.detail_penjualan
UNION ALL SELECT 'mutasi_stok',count(*) FROM public.mutasi_stok;
UPDATE finka_import_c9b49e93c6f2._meta SET phase='applied',applied_at=clock_timestamp() WHERE singleton;
COMMIT;

-- FINKACARE: 00 HAPUS DATA LAMA DAN PERSIAPAN IMPOR BERTAHAP
-- Gunakan Supabase SQL Editor sebagai postgres/project owner.
-- FILE PERTAMA INI MENGHAPUS SELURUH DATA BISNIS LAMA PADA 9 TABEL APLIKASI.
-- Buat backup sebelum menjalankan. Akun login/admin, RLS, policy dan fungsi aplikasi dipertahankan.
-- Jangan gunakan aplikasi selama impor. Data baru muncul setelah langkah final berhasil.
-- Jika dijalankan ulang, data bisnis dihapus lagi dan semua file data harus diulang.
BEGIN;
SET LOCAL lock_timeout = '10s';
SET LOCAL statement_timeout = '300s';
SET LOCAL standard_conforming_strings = on;
SET LOCAL TIME ZONE 'Asia/Jakarta';

DO $schema_guard$
DECLARE existing_marker text;
BEGIN
 IF EXISTS(SELECT 1 FROM pg_namespace WHERE nspname='finka_import_c9b49e93c6f2') THEN
  SELECT obj_description(oid,'pg_namespace') INTO existing_marker FROM pg_namespace WHERE nspname='finka_import_c9b49e93c6f2';
  IF existing_marker IS DISTINCT FROM 'FinkaCare import staging finka-c9b49e93c6f2-staged-v2' THEN
   RAISE EXCEPTION 'Nama schema staging telah digunakan untuk objek lain; persiapan dibatalkan.';
  END IF;
 END IF;
END
$schema_guard$;
CREATE SCHEMA IF NOT EXISTS finka_import_c9b49e93c6f2;
COMMENT ON SCHEMA finka_import_c9b49e93c6f2 IS 'FinkaCare import staging finka-c9b49e93c6f2-staged-v2';
REVOKE ALL ON SCHEMA finka_import_c9b49e93c6f2 FROM PUBLIC;
DROP FUNCTION IF EXISTS finka_import_c9b49e93c6f2._part_audit(integer);
DROP TABLE IF EXISTS finka_import_c9b49e93c6f2._finka_obat, finka_import_c9b49e93c6f2._finka_batch, finka_import_c9b49e93c6f2._finka_supplier, finka_import_c9b49e93c6f2._finka_penerimaan, finka_import_c9b49e93c6f2._finka_detail_masuk, finka_import_c9b49e93c6f2._finka_penjualan, finka_import_c9b49e93c6f2._finka_detail_keluar, finka_import_c9b49e93c6f2._finka_mutasi, finka_import_c9b49e93c6f2._finka_master_asli, finka_import_c9b49e93c6f2._manifest, finka_import_c9b49e93c6f2._meta;
CREATE TABLE finka_import_c9b49e93c6f2._finka_obat (id bigint PRIMARY KEY, kode text UNIQUE, nama text NOT NULL, bentuk text, satuan text NOT NULL, harga numeric, kategori text, jenis text, _load_part integer NOT NULL);
CREATE TABLE finka_import_c9b49e93c6f2._finka_batch (id bigint PRIMARY KEY, obat_id bigint NOT NULL REFERENCES finka_import_c9b49e93c6f2._finka_obat(id), nomor text NOT NULL, expired date, stok numeric NOT NULL CHECK (stok >= 0), _load_part integer NOT NULL);
CREATE TABLE finka_import_c9b49e93c6f2._finka_supplier (id bigint PRIMARY KEY, nama text NOT NULL, _load_part integer NOT NULL);
CREATE TABLE finka_import_c9b49e93c6f2._finka_penerimaan (id bigint PRIMARY KEY, faktur text NOT NULL, supplier_id bigint REFERENCES finka_import_c9b49e93c6f2._finka_supplier(id), tanggal date, catatan text, _load_part integer NOT NULL);
CREATE TABLE finka_import_c9b49e93c6f2._finka_detail_masuk (penerimaan_id bigint REFERENCES finka_import_c9b49e93c6f2._finka_penerimaan(id), batch_id bigint REFERENCES finka_import_c9b49e93c6f2._finka_batch(id), jumlah numeric CHECK (jumlah > 0), _load_part integer NOT NULL);
CREATE TABLE finka_import_c9b49e93c6f2._finka_penjualan (id bigint PRIMARY KEY, referensi text UNIQUE NOT NULL, tanggal timestamptz NOT NULL, total numeric CHECK(total >= 0), catatan text, _load_part integer NOT NULL);
CREATE TABLE finka_import_c9b49e93c6f2._finka_detail_keluar (penjualan_id bigint REFERENCES finka_import_c9b49e93c6f2._finka_penjualan(id), batch_id bigint REFERENCES finka_import_c9b49e93c6f2._finka_batch(id), jumlah numeric CHECK(jumlah > 0), harga numeric CHECK(harga >= 0), subtotal numeric CHECK(subtotal >= 0), _load_part integer NOT NULL);
CREATE TABLE finka_import_c9b49e93c6f2._finka_mutasi (batch_id bigint REFERENCES finka_import_c9b49e93c6f2._finka_batch(id), jenis text CHECK(jenis IN ('masuk','keluar')), jumlah numeric CHECK(jumlah > 0), referensi text, catatan text, tanggal timestamptz, _load_part integer NOT NULL);
CREATE TABLE finka_import_c9b49e93c6f2._finka_master_asli (baris integer PRIMARY KEY, nilai jsonb NOT NULL, kategori_warna text, _load_part integer NOT NULL);
CREATE TABLE finka_import_c9b49e93c6f2._meta (
 singleton boolean PRIMARY KEY DEFAULT true CHECK(singleton),
 package_id text NOT NULL, phase text NOT NULL CHECK(phase IN ('loading','applied')),
 total_parts integer NOT NULL, source_sha256 text NOT NULL, applied_at timestamptz
);
INSERT INTO finka_import_c9b49e93c6f2._meta (singleton,package_id,phase,total_parts,source_sha256)
VALUES (true,'finka-c9b49e93c6f2-staged-v2','loading',25,'c9b49e93c6f28826fa8c2c312cdd05665b13e9c1537dfb6ec42a7d4d0e51f027');
CREATE TABLE finka_import_c9b49e93c6f2._manifest (
 part_no integer PRIMARY KEY, filename text NOT NULL, sql_sha256 text NOT NULL,
 expected_rows bigint NOT NULL, loaded_rows bigint, data_md5 text, loaded_at timestamptz
);
INSERT INTO finka_import_c9b49e93c6f2._manifest (part_no,filename,sql_sha256,expected_rows) VALUES
(1,'01_DATA_01.sql','b124b5298e306c3e5ec2060b40ee16d76be9bba24b6e4609a72137f15d497a3f',471),
(2,'02_DATA_02.sql','2454a94aaeab2663c73f007fffaba6a2efb9b10f5aba218c4c6e6b660dfb529a',934),
(3,'03_DATA_03.sql','c4b600127fe658bfde0396118cfbd9584eb2285b5cb23cd4cc804f0a06c27d81',232),
(4,'04_DATA_04.sql','00fadba0e197d5d426af5b4c19320782df808bea3e1a0b65f9bbbfea07a36449',33),
(5,'05_DATA_05.sql','89bbfbca942225fe1cafe1c9650aa861fdceae10b2cedade2b99323949135d3b',533),
(6,'06_DATA_06.sql','bbb9abbb37bb704966e908369f34933cf7fa5295f19772bb106c0887901222d9',152),
(7,'07_DATA_07.sql','c5f8d10f299e669b519a0790af836f114b345cef930f60ea7d659e80bae99379',151),
(8,'08_DATA_08.sql','de10f3442658655b6b61f3140a0327cbe06f4190579ddb80702361ff105ad8ed',151),
(9,'09_DATA_09.sql','ae604130f18de33ce689fe86589d01c92741eb73d1baa9ccf5f24f116826ac7b',151),
(10,'10_DATA_10.sql','172a59cb887decce2baa3c8126e72344ec6c8816d49c70560ad8f978eb935e8c',151),
(11,'11_DATA_11.sql','a2b6db5d90bf31bec27699851439a30701386908f2462db6fb6fcdf8d2baa449',417),
(12,'12_DATA_12.sql','c0b94ada52d4a562ce620f8d1cd0956909a31c34b06e997387476e97d667d937',817),
(13,'13_DATA_13.sql','b8625571cb39d85d1aa1e495f4a3623b3df6e0c73d5500428183b7f1059b880d',315),
(14,'14_DATA_14.sql','31276bd34264dd318d91e698ca05117d9d8be4862aa72e2bcf308bd811f689ef',301),
(15,'15_DATA_15.sql','69d90ce64bfe06bfa73f3b2c5892f4f691952b154891b091fac60df27fa8ef94',300),
(16,'16_DATA_16.sql','3e3f16ed89abdd8daa7df98f5bf38bf74c17552e0e4cccfeeb92cdc86f390e86',301),
(17,'17_DATA_17.sql','21593153db6d1b56d8fabda2d1b0b0c888df0216b62a1d1f7a37c2cddfc19395',321),
(18,'18_DATA_18.sql','a74c822f19676381b88779e11abb3317d3b2c926019dfb2e9a5be2830e0eb9c9',264),
(19,'19_DATA_19.sql','71593c4cd6dfeed4d946cb9e22737275d79a8c5dc1295ea694532efc5aa0269f',152),
(20,'20_DATA_20.sql','e104685b2898c313bc8a4288d1be6c157e4d595be784f6724403897e487761f8',152),
(21,'21_DATA_21.sql','e41f2ab4569479dfabfc9cf286d5eeae22e74739775dd25cf145e8cf0b0d68ed',152),
(22,'22_DATA_22.sql','21995f1c40faa7a2f3bb1a72ade155d6b32257e2b955122368d0444f06addfda',148),
(23,'23_DATA_23.sql','068941127b40b22911db94f9992e57e3c2649b0be9ddad62291613f735c15efe',144),
(24,'24_DATA_24.sql','b8ce8a771203a775ee099930124d7a94242031f31c457e6a851e21bcd09e44d9',146),
(25,'25_DATA_25.sql','db406b9696fb478718cd3caf74dd1dc23b89c9936369c69bc0aabf6fb3c0a534',49);
CREATE FUNCTION finka_import_c9b49e93c6f2._part_audit(p_part integer)
RETURNS TABLE(row_count bigint,fingerprint text)
LANGUAGE sql STABLE SECURITY INVOKER SET search_path=pg_catalog
AS $audit$
 SELECT count(*),md5(coalesce(string_agg(table_name||':'||payload,E'\n' ORDER BY table_name,payload),''))
 FROM (
 SELECT '_finka_obat' AS table_name, to_jsonb(r)::text AS payload FROM finka_import_c9b49e93c6f2._finka_obat r WHERE r._load_part=p_part
UNION ALL
SELECT '_finka_batch' AS table_name, to_jsonb(r)::text AS payload FROM finka_import_c9b49e93c6f2._finka_batch r WHERE r._load_part=p_part
UNION ALL
SELECT '_finka_supplier' AS table_name, to_jsonb(r)::text AS payload FROM finka_import_c9b49e93c6f2._finka_supplier r WHERE r._load_part=p_part
UNION ALL
SELECT '_finka_penerimaan' AS table_name, to_jsonb(r)::text AS payload FROM finka_import_c9b49e93c6f2._finka_penerimaan r WHERE r._load_part=p_part
UNION ALL
SELECT '_finka_detail_masuk' AS table_name, to_jsonb(r)::text AS payload FROM finka_import_c9b49e93c6f2._finka_detail_masuk r WHERE r._load_part=p_part
UNION ALL
SELECT '_finka_penjualan' AS table_name, to_jsonb(r)::text AS payload FROM finka_import_c9b49e93c6f2._finka_penjualan r WHERE r._load_part=p_part
UNION ALL
SELECT '_finka_detail_keluar' AS table_name, to_jsonb(r)::text AS payload FROM finka_import_c9b49e93c6f2._finka_detail_keluar r WHERE r._load_part=p_part
UNION ALL
SELECT '_finka_mutasi' AS table_name, to_jsonb(r)::text AS payload FROM finka_import_c9b49e93c6f2._finka_mutasi r WHERE r._load_part=p_part
UNION ALL
SELECT '_finka_master_asli' AS table_name, to_jsonb(r)::text AS payload FROM finka_import_c9b49e93c6f2._finka_master_asli r WHERE r._load_part=p_part
 ) all_rows;
$audit$;
REVOKE ALL ON ALL TABLES IN SCHEMA finka_import_c9b49e93c6f2 FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA finka_import_c9b49e93c6f2 FROM PUBLIC;
-- Schema staging tidak diekspos kepada role aplikasi anon/authenticated.
DO $restrict_app_roles$
DECLARE role_name text;
BEGIN
 FOREACH role_name IN ARRAY ARRAY['anon','authenticated'] LOOP
  IF EXISTS(SELECT 1 FROM pg_roles WHERE rolname=role_name) THEN
   EXECUTE format('REVOKE ALL ON SCHEMA %I FROM %I','finka_import_c9b49e93c6f2',role_name);
   EXECUTE format('REVOKE ALL ON ALL TABLES IN SCHEMA %I FROM %I','finka_import_c9b49e93c6f2',role_name);
   EXECUTE format('REVOKE ALL ON ALL FUNCTIONS IN SCHEMA %I FROM %I','finka_import_c9b49e93c6f2',role_name);
  END IF;
 END LOOP;
END
$restrict_app_roles$;
LOCK TABLE public.obat, public.batch_obat, public.supplier, public.penerimaan, public.detail_penerimaan, public.mutasi_stok, public.pengaturan_opsi, public.penjualan, public.detail_penjualan IN ACCESS EXCLUSIVE MODE;
-- Hindari trigger aplikasi menghitung stok/riwayat dua kali. Trigger internal FK tetap aktif.
-- Keadaan awal trigger (enabled/disabled/replica/always) dikembalikan tepat seperti semula.
CREATE TEMP TABLE _finka_trigger_awal ON COMMIT DROP AS
SELECT n.nspname AS schema_name,c.relname AS table_name,t.tgname AS trigger_name,t.tgenabled
FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace
WHERE n.nspname='public' AND c.relname IN ('obat','batch_obat','supplier','penerimaan',
 'detail_penerimaan','mutasi_stok','pengaturan_opsi','penjualan','detail_penjualan') AND NOT t.tgisinternal;
DO $pause_triggers$
DECLARE r record;
BEGIN
 FOR r IN SELECT DISTINCT schema_name,table_name FROM _finka_trigger_awal LOOP
  EXECUTE format('ALTER TABLE %I.%I DISABLE TRIGGER USER',r.schema_name,r.table_name);
 END LOOP;
END
$pause_triggers$;


TRUNCATE TABLE public.detail_penjualan,public.penjualan,public.detail_penerimaan,
 public.mutasi_stok,public.penerimaan,public.batch_obat,public.obat,
 public.supplier,public.pengaturan_opsi RESTART IDENTITY;
DO $restore_triggers$
DECLARE r record; action text;
BEGIN
 FOR r IN SELECT * FROM _finka_trigger_awal LOOP
  action := CASE r.tgenabled WHEN 'O' THEN 'ENABLE TRIGGER' WHEN 'D' THEN 'DISABLE TRIGGER'
   WHEN 'R' THEN 'ENABLE REPLICA TRIGGER' WHEN 'A' THEN 'ENABLE ALWAYS TRIGGER' END;
  IF action IS NULL THEN RAISE EXCEPTION 'Status trigger tidak dikenal.'; END IF;
  EXECUTE format('ALTER TABLE %I.%I %s %I',r.schema_name,r.table_name,action,r.trigger_name);
 END LOOP;
END
$restore_triggers$;
COMMIT;
SELECT 'DATA LAMA SUDAH DIHAPUS; PERSIAPAN BERHASIL' AS status,25 AS jumlah_file_data,'Lanjutkan 01_DATA_01.sql' AS langkah_berikut;

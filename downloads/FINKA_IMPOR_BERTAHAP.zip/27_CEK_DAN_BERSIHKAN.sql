-- FINKACARE: PEMERIKSAAN DAN PEMBERSIHAN STAGING
-- Jalankan setelah 26_ISI_DATA_BARU.sql berhasil. Tidak menghapus data aplikasi.
BEGIN;
SET LOCAL lock_timeout = '10s';
SET LOCAL statement_timeout = '300s';
SET LOCAL standard_conforming_strings = on;
SET LOCAL TIME ZONE 'Asia/Jakarta';

DO $cleanup_guard$
BEGIN
 IF (SELECT package_id FROM finka_import_c9b49e93c6f2._meta WHERE singleton) IS DISTINCT FROM 'finka-c9b49e93c6f2-staged-v2'
    OR (SELECT phase FROM finka_import_c9b49e93c6f2._meta WHERE singleton) <> 'applied' THEN
  RAISE EXCEPTION 'Langkah final belum berhasil; staging belum boleh dibersihkan.';
 END IF;
END
$cleanup_guard$;
SELECT 'obat' AS tabel,count(*) AS jumlah FROM public.obat
UNION ALL SELECT 'batch_obat',count(*) FROM public.batch_obat
UNION ALL SELECT 'supplier',count(*) FROM public.supplier
UNION ALL SELECT 'penerimaan',count(*) FROM public.penerimaan
UNION ALL SELECT 'detail_penerimaan',count(*) FROM public.detail_penerimaan
UNION ALL SELECT 'penjualan',count(*) FROM public.penjualan
UNION ALL SELECT 'detail_penjualan',count(*) FROM public.detail_penjualan
UNION ALL SELECT 'mutasi_stok',count(*) FROM public.mutasi_stok;
DROP FUNCTION finka_import_c9b49e93c6f2._part_audit(integer);
DROP TABLE finka_import_c9b49e93c6f2._finka_obat, finka_import_c9b49e93c6f2._finka_batch, finka_import_c9b49e93c6f2._finka_supplier, finka_import_c9b49e93c6f2._finka_penerimaan, finka_import_c9b49e93c6f2._finka_detail_masuk, finka_import_c9b49e93c6f2._finka_penjualan, finka_import_c9b49e93c6f2._finka_detail_keluar, finka_import_c9b49e93c6f2._finka_mutasi, finka_import_c9b49e93c6f2._finka_master_asli, finka_import_c9b49e93c6f2._manifest, finka_import_c9b49e93c6f2._meta;
DROP SCHEMA finka_import_c9b49e93c6f2;
COMMIT;

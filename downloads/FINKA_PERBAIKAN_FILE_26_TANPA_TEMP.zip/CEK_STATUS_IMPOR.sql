-- Hanya memeriksa status. Tidak menghapus atau mengubah data.
-- Jalankan pada proyek yang dipakai menjalankan file 00-25, sebagai postgres/project owner.
SELECT
 (SELECT phase FROM finka_import_c9b49e93c6f2._meta WHERE singleton) AS status_impor,
 (SELECT count(*) FROM finka_import_c9b49e93c6f2._manifest WHERE loaded_at IS NOT NULL) AS bagian_data_selesai,
 (SELECT count(*) FROM finka_import_c9b49e93c6f2._manifest) AS total_bagian_data,
 (SELECT count(*) FROM finka_import_c9b49e93c6f2._finka_obat) AS obat_di_penampungan,
 (SELECT count(*) FROM finka_import_c9b49e93c6f2._finka_batch) AS batch_di_penampungan,
 (SELECT count(*) FROM public.obat) AS obat_di_aplikasi,
 (SELECT count(*) FROM public.batch_obat) AS batch_di_aplikasi;
